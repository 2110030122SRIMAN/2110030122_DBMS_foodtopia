from django.apps import AppConfig


class FoodappConfig(AppConfig):
    name = 'foodapp'
